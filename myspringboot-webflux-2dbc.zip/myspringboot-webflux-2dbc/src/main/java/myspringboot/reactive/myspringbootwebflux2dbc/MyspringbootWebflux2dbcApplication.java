package myspringboot.reactive.myspringbootwebflux2dbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyspringbootWebflux2dbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyspringbootWebflux2dbcApplication.class, args);
	}

}
